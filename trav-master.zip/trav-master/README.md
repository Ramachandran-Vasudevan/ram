# trav

Travis build status ![Build Status](https://travis-ci.org/vnextcoder/trav.svg?branch=master "Travis Build Status")

Circle ![Circle STatus](https://circleci.com/gh/vnextcoder/trav.svg?style=shield&circle-token=:circle-token "Circle Status")


New notes after slack
